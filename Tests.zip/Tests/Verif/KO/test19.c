//erreur ligne 4

void main(){

    bool a = 0; 
    int c = 1;

    c = a %4
}