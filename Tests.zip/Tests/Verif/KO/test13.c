void main(){
//erreur ligne 6
    int a = 2;
    bool b = true;
    bool c = false;
    a = b - c;
}