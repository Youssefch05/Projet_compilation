//error line 5
void main(){
    
    bool b = true;
    bool c = b|6;
    

    

}