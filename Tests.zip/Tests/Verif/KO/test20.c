//erreur ligne 8

void main(){

    bool a = 0; 
    int c = 1;

    c = c % a;
}