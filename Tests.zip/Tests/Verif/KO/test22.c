 void main(){
    bool a = 0; 
    bool c = 1;
    int b = 3;

    a = b != c;
    }