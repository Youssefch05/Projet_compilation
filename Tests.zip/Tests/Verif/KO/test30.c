//erreur ligne 5
void main(){
    int a = 2;
    bool b = true;
    bool c = a&b;
    
    

}