void main(){
    //erreur ligne 6
    int a = 2;
    bool b =1
    int c;
    c = a/b;

    
}