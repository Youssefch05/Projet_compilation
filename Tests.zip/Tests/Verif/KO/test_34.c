//error line 4
void main(){
    bool b = true;
    bool c = b&2;
    

    

}