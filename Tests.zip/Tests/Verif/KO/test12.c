void main(){
//erreur ligne 5 
    int a = 2;
    bool b = true;
    bool c = false;
    c = a - b;
}