void main(){

    //erreur ligne 7
    int a = 2;
   int b = a;
    bool c;
    c = a/b;


    
}