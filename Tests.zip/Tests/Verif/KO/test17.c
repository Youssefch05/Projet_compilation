//erreur ligne 8
void main(){


    bool a = 2
    int b  = 4;

    int c = a * 4;
}