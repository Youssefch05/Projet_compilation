void main(){
    //erreur ligne 6
    int a = 2
    bool b  = 4;

    int c = a * b;


    
}