//erreur ligne 6

int a =0;

void main(){
    int a = a;
 
    

}