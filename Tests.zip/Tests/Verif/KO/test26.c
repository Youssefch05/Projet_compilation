 //erreur ligne 3
void main(){
    bool a = 2;

}