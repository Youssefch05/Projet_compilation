//erreur ligne 2
void main(){
    bool c = true;
    int a = -c;
}