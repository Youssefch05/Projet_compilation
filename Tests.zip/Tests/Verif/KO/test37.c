void main(){
    
bool b = true;

int a = b;
}
