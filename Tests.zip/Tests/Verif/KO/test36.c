//error line 5
void main(){
    int a = 4
    bool b = true;
    bool c = a|b;
    

    

}